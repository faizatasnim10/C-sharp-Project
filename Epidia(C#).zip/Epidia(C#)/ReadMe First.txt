###################################################################################################################
##***************************************************************************************************************##
##********************************** MUST BE READ THIS TEXT FILE BEFORE RUN EPIDIA ******************************##
##***************************************************************************************************************##
###################################################################################################################


=>Software and frameworks used
       1.Microsoft Visual Studio 2019 Version 16.11.0.
       2. .Net framework Version 4.0
       3.SQL Server Management Studio Version 18
       4.Guna_UI_Framework_Ultimate_v2.0.0.1 

=>Installation Guide:
            Go to EPIDIA->bin->Debug->Epidia.exe>Click Ok
            After Installing, Open the software by clicking the shortcut in the desktop.

=>NOTE: ADMIN USERNAME IS : admin
              PASSWORD IS : admin

=>User Guide:

1. Click continue to go to Homepage.
2. Go to Games and teams and click on the button to see the Team list.
3. Go to Home page and click on Schedule to see the timetable for different Game event.
4. Go to Home page and click on News to stay update about the Games event.
5. Go to Home page and click on Ranking to see the rank for different Teams according to the Games.
6. Go to Home page and click on Login.Here user can Sign up or create a account by clicking register now or if the user is a existing user then he/she can login.
7. User can see their Team members by clicking on my Team.
8. Go to My page and click on my profile. Click on show profile to see the details about user's own profile.
9. User can update his/her profile by filling up the essential details.
10.Any user can contact admin if they face any problem.
11.Admin can control and analyze players in the manage players.
12.Admin can also update and remove on players.
13.Admin can watch the entire details about players except security credential (password).


=>Project limitations:
        1. It is not an web based application.
        2. Our user interface is not that upper high level.
        3. There are no virus/malicious in this software so please ignore the warning message if it shows.

=>Developed By: LIGHTING MYSTERY

             1. SADIA AFRIN SARA           -> 20-41834-1
             2. SHARIA TASNIM ADRITA       -> 20-41895-1
             3. FAIZA TASNIM               -> 19-41552-3

=>Supervised By:
               MD.NAZMUL HOSSAIN
               Lecturer
               American International University of Bangladesh

All thanks to Almighty Allah, without His blessing, the idea and work was totally impossible.
Also we want to dedicate our project to our honourable faculty who tried tieredlessly throughout the semester to teach us.

                                        ***We Are Always Ready For Your Help.***

=>If you facing any kind of problem then please contact with us.

Send Your Feedback About Project-EPIDIA on: fz.tasnim10@gmail.com

For Any Kind Of Query Please Contact With Us:' sadiasara49@gmail.com ' 
                                          or ' aditasnim88@gmail.com '
                                          or ' fz.tasnim10@gmail.com '


"THANK YOU FOR BEING WITH US."    -LIGHTING MYSTERY

all right reserved by @lighting mystery